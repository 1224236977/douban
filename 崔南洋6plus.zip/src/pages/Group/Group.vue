<template>
  <div class="group">
      <MyHeader>
        <span>小组</span>
        <img src="../../assets/images/ic_group_search.png" slot="leftImg">
        <img src="../../assets/images/ic_chat_green.png" slot="rightImg">
      </MyHeader>
      <div class="group_main">
          <div class="group_mainTop"></div>
          <div class="group_mainBot">
              <div class="Bot_bg"><span>精选推荐</span></div>
              <GroupItem v-for="(item,index) in arr ":key="item.id" :tit="item.tit">
                  <GroupText v-for="(item2,index2) in item.inArr " :key="item.id" :url="item2.url" :title="item2.title" :inner="item2.inner" :num="item2.num"></GroupText>
              </GroupItem>
          </div>
      </div>
   </div>
</template>
<script>
  import MyHeader from '../../components/Header'
  import GroupItem from '../../components/GroupItem'
  import GroupText from '../../components/GroupText'
  export default{
    components:{
      MyHeader,
      GroupItem,
      GroupText
    },
    data:function () {
      return{
          arr:[
            {
                tit:'影视',
                inArr:[
                  {
                      url:require('../../assets/images/group_03.jpg'),
                      title:"我们看剧爱吐槽!",
                      inner:"什么剧都看，就是爱吐槽，吐演技，吐剧情，吐编剧。吐槽要吐出水平，吐出境界！",
                      num:'8660人'
                  },
                  {
                    url:require('../../assets/images/group_03.jpg'),
                    title:"我们看剧爱吐槽!",
                    inner:"什么剧都看，就是爱吐槽，吐演技，吐剧情，吐编剧。吐槽要吐出水平，吐出境界！",
                    num:'8660人'
                  },
                  {
                    url:require('../../assets/images/group_03.jpg'),
                    title:"我们看剧爱吐槽!",
                    inner:"什么剧都看，就是爱吐槽，吐演技，吐剧情，吐编剧。吐槽要吐出水平，吐出境界！",
                    num:'8660人'
                  }
                ]
            },
            {
              tit:'读书',
              inArr:[
                {
                  url:require('../../assets/images/group_03.jpg'),
                  title:"我们看剧爱吐槽!",
                  inner:"什么剧都看，就是爱吐槽，吐演技，吐剧情，吐编剧。吐槽要吐出水平，吐出境界！",
                  num:'8660人'
                },
                {
                  url:require('../../assets/images/group_03.jpg'),
                  title:"我们看剧爱吐槽!",
                  inner:"什么剧都看，就是爱吐槽，吐演技，吐剧情，吐编剧。吐槽要吐出水平，吐出境界！",
                  num:'8660人'
                },
                {
                  url:require('../../assets/images/group_03.jpg'),
                  title:"我们看剧爱吐槽!",
                  inner:"什么剧都看，就是爱吐槽，吐演技，吐剧情，吐编剧。吐槽要吐出水平，吐出境界！",
                  num:'8660人'
                }
              ]
            }
          ]
      }
    }
  }
</script>
<style>
  .group_main{height: 736px;overflow: hidden}
  .group_mainTop{height: 176px;background: url("../../assets/images/group_bg_02.jpg") no-repeat;background-size: cover}
  .group_mainBot{padding: 22px 12px 0 12px;height: 538px; }
  .Bot_bg{height: 68px;background: url("../../assets/images/ic_rec_group_banner_6.png") no-repeat;background-size: cover;
    border-radius: 4px;position: relative;margin-bottom: 34px;}
  .Bot_bg span{color: #fff;position: absolute;left: 12px;bottom: 4px;font-size: 14px;}
</style>


