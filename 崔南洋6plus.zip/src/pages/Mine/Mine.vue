<template>
  <div class="mine">
    <MyHeader>
      <span>我的</span>
      <img src="../../assets/images/ic_settings.png" slot="rightImg">
    </MyHeader>
    <div class="mine_main">
      <!--登录注册-->
      <div class="register">
        <div class="register_pic"><img src="../../assets/images/avatar_male_70.png"></div>
        <div class="register_frame"><a href="##">登录 / 注册</a> </div>
      </div>
      <!--提醒-->
      <div class="remind">
        <div class="remind_top">
          <img src="../../assets/images/ic_mine_notification.png" class="l_pic">
          <span>提醒</span>
          <img src="../../assets/images/ic_arrow_gray_small.png" class="r_pic right_arrows">
        </div>
        <div class="remind_bottom">暂无新提醒</div>
      </div>
      <!--icon-->
      <div class="mine_icons">
        <MineItem v-for="(item,index) in MineArr":key="item.id" :url="item.url" :txt="item.txt"></MineItem>
        <div class="mine_line"></div>
        <div class="mine_line mine_line2"></div>
      </div>
    </div>
  </div>
</template>
<script>
  import MyHeader from '../../components/Header'
  import MineItem from '../../components/MineItem'
  export default{
    data:function () {
      return {
          MineArr:[
            {
                url:require('../../assets/images/ic_my_likes.png'),
                txt:"喜欢"
            },
            {
              url:require('../../assets/images/ic_my_note.png'),
              txt:"日记"
            },
            {
              url:require('../../assets/images/ic_my_album.png'),
              txt:"相册"
            },
            {
              url:require('../../assets/images/ic_my_status.png'),
              txt:"我的广播"
            },
            {
              url:require('../../assets/images/ic_my_movies_tvs.png'),
              txt:"电视·电视"
            },
            {
              url:require('../../assets/images/ic_my_books.png'),
              txt:"读书"
            },
            {
              url:require('../../assets/images/ic_my_music.png'),
              txt:"音乐"
            },
            {
              url:require('../../assets/images/ic_my_events.png'),
              txt:"同城活动"
            },
            {
              url:require('../../assets/images/ic_my_likes.png'),
              txt:"豆瓣时间"
            },
            {
              url:require('../../assets/images/ic_my_doulist.png'),
              txt:"豆列"
            },
            {
              url:require('../../assets/images/ic_my_orders.png'),
              txt:"订单"
            },
            {
              url:require('../../assets/images/ic_my_wallet.png'),
              txt:"钱包"
            }
          ]
      }
    },
    components:{
      MyHeader,
      MineItem
    },
  }
</script>
<style>
  .mine_main{background-color: #f8f8f8;height: 736px;}
  .register{height: 100px;background-color: #51bf63;padding-top: 26px;text-align: left}
  .register_pic{width: 66px;height: 66px;border-radius: 70px;background-color: #fff;border: 2px solid #fff;
    display: inline-block;margin: 0px 66px 0px 20px;}
  .register_pic img{width: 100%;}
  .register_frame{display: inline-block;width: 178px;height: 38px;border-radius: 4px;border: 1px solid #fff;line-height: 38px;
  text-align: center;position: relative;bottom: 26px;}
  .register_frame a{color: #fff;font-size: 12px;}
  .remind{height: 100px;padding-left: 20px;background-color: #fff;margin-top: 14px;text-align: left}
  .remind_top{height: 53px;border-bottom: 1px solid #f2f2f2;line-height: 53px;}
  .remind_top img{width: 30px;padding-top: 12px;}
  .remind_top span{font-size: 14px;padding-left: 14px}
  .l_pic{float: left}
  .r_pic{float: right}
  .right_arrows{padding-right: 12px}
  .remind_bottom{height: 46px;line-height: 46px;text-align: center;font-size: 14px;color: #d1d1d1}
  .mine_icons{height: 310px;margin-top: 16px;background-color: #fff;position: relative}
  .mine_line{position: absolute;height: 1px;width: 100%;background-color:#f6f6f6;left: 0 ;top: 100px;}
  .mine_line2{bottom: 106px;top: auto}
</style>
