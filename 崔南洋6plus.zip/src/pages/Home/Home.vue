<template>
    <div class="home">
        <MyHeader col="#42bd55">
          <div class="homeHeader_wrap">
            <input type="text" class="home_search" placeholder="影视 图书 唱片 小组等">
            <img src="../../assets/images/ic_search_gray.png" class="search_icon">
            <img src="../../assets/images/ic_scan_gray.png" slot="leftImg" class="scan_icon">
            <img src="../../assets/images/ic_chat_white.png" slot="rightImg" class="weixin_icon">
          </div>
        </MyHeader>
        <div class="banner">
          <Banner swiperid="swiper01" paginationDirection="right" :button="true">
            <div class="swiper-slide" slot="swiper-con"><img src="../../assets/images/banner/01.jpg"></div>
            <div class="swiper-slide" slot="swiper-con"><img src="../../assets/images/banner/02.jpg"></div>
            <div class="swiper-slide" slot="swiper-con"><img src="../../assets/images/banner/03.jpg"></div>
            <!--<img src="../../assets/images/banner/01.jpg" slot="swiper-con">-->
            <!--<img src="../../assets/images/banner/02.jpg" slot="swiper-con">-->
            <!--<img src="../../assets/images/banner/03.jpg" slot="swiper-con">-->
          </Banner>
        </div>
        <div class="home_main">
          <div class="hot"><span>热点</span></div>
          <HomeItem v-for="(item,index) in arr" :key="item.id" :url='item.target.author.avatar' :title="item.title" :inner="item.target.desc" :author="'作者：'+item.target.author.name"></HomeItem>
        </div>
    </div>
</template>
<script>
  import MyHeader from '../../components/Header'
  import HomeItem from '../../components/HomeItem'
  import Banner from '../../components/Bannere'
//  import { swiper, swiperSlide } from 'vue-awesome-swiper'
  export default{
      components:{
        MyHeader,
        HomeItem,
        Banner,
      },
      data:function () {
        return {
//            arr:[
//              {
//                url:require('../../assets/images/home_03.jpg'),
//                title:"我在论文“造假”工厂打工:代写、包发,年产值10亿",
//                inner:'只需要三四个小时，就能攒出一篇完全可以骗过查重系统的课程论文。',
//                author:'作者：土豆公社'
//              },
//              {
//                url:require('../../assets/images/home_03.jpg'),
//                title:"我在论文“造假”工厂打工:代写、包发,年产值10亿",
//                inner:'只需要三四个小时，就能攒出一篇完全可以骗过查重系统的课程论文。',
//                author:'作者：土豆公社'
//              },
//            ],
            arr:[]
        }
      },
      mounted:function () {
        this.search()
      },
      methods:{
        search:function () {
            this.axios.get('/api/homeData').then((response) => {
              console.log(response.data.data.recommend_feeds);
              this.arr=response.data.data.recommend_feeds
            })
          }
      }
  }
</script>
<style>
    .home_search{height: 30px;width: 304px;border-radius: 4px;border: none;padding: 0 30px;margin-right: 30px;}
    .homeHeader_wrap{position: relative}
    .homeHeader_wrap img{width: 20px;}
    .search_icon{position: absolute;left: 15px;top: 13px;}
    .scan_icon{position: absolute;right: 48px;top: 13px;}
    .weixin_icon{position: absolute;right: 12px;top: 13px;}
    .banner{height: 138px;background-color: pink;margin-bottom: 38px;}
    .banner img{width: 100%}
    .home_main{position: relative}
    .hot{height: 20px;border-left: 4px solid #ff7b40;text-align: left;padding-left: 17px;position: absolute;top: -20px}
    .hot span{color:#ff7b40;font-size: 16px}
</style>
