<template>
  <div class="minelist">
      <img :src="url">
      <p v-text="txt"></p>
  </div>
</template>
<script>
  export default {
      props:['url','txt']
  }
</script>
<style>
  .minelist{width: 25%;float: left;text-align: center;height: 33%;}
  .minelist img{width: 30px;padding-top: 21px}
  .minelist p{font-size: 15px;color: #373737;}
</style>
