<template>
      <div class="groupWrap">
          <div class="group_pic"><img :src="url"></div>
          <div class="group_text">
            <h4 v-text="title">我们看剧爱吐槽！</h4>
            <span v-text="inner">什么剧都看，就是爱吐槽，吐演技，吐剧情，吐编剧。吐槽要吐出水平，吐出境界！</span>
          </div>
          <div class="group_people" v-text="num">8660人</div>
          <div class="yes"></div>
      </div>
</template>
<script>
  export default {
      props:['url','title','inner','num']
  }
</script>
<style>
  .groupWrap{height: 60px;text-align: left;margin-bottom: 20px;}
  .group_pic{width: 50px;height: 60px;margin-right: 10px;float: left}
  .group_pic img {width: 50px;margin-top: 5px;}
  .group_text{width: 236px;float: left}
  .group_text h4{font-size: 16px;}
  .group_text span{font-size: 10px;color: #a0a0a0;font-family: 微软雅黑}
  .group_people{width: 50px;text-align: right;float: left;font-size: 12px;line-height: 60px;color: #cdcdcd}
  .yes{float: left;width: 24px;height: 24px;cursor: pointer;background: url("../assets/images/ic_group_check_anonymous.png");
    background-size: cover;margin-left: 12px;margin-top: 16px;}
</style>
