<template>
  <div class="audioPic">
    <img :src="adurl">
    <p v-text="name">神奇女侠</p>
    <span v-text="comment">暂无评论</span>
  </div>
</template>
<script>
  export default {
    props:['adurl','name','comment']
  }
</script>
<style>
  .audioPic{float: left;margin-right: 10px;}
  .audioPic img{width: 100px;}
  .audioPic p{font-size: 14px;padding: 2px 0px;}
  .audioPic span{font-size: 12px;color: #c0c0c0}
</style>
