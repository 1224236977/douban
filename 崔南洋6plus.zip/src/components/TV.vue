<template>
  <div class="tv_main">
    <AudioItem v-for="(item,index) in arr" :key="item.id":tlt="item.tlt">
      <AudioPic v-for="(item2,index2) in item.inArr":key="item.id" :adurl="item2.adurl" :name="item2.name" :comment="item2.comment"></AudioPic>
    </AudioItem>
  </div>
</template>
<script>
  import AudioItem from './AudioItem'
  import AudioPic from './AudioPic'
  export default{
    components:{
      AudioItem,
      AudioPic
    },
    data:function () {
      return{
        arr:[
          {
            tlt:"今日更新",
            inArr:[
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
            ]
          },
          {
            tlt:"近期值得看的国产剧",
            inArr:[
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/audiopic_03.jpg'),
                name:'神奇女侠',
                comment:"暂无评论"
              },
            ]
          }
        ]
      }
    }
  }
</script>
