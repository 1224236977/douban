<template>
  <div class="music_main">
    <AudioItem v-for="(item,index) in arr":key="item.id" :tlt="item.tlt">
      <AudioPic v-for="(item2,index) in item.inArr":key="item.id" :adurl="item2.adurl" :name="item2.name" :comment="item2.comment"></AudioPic>
    </AudioItem>
  </div>
</template>
<script>
  import AudioItem from './AudioItem'
  import AudioPic from './AudioPic'
  export default{
    components:{
      AudioItem,
      AudioPic
    },
    data:function () {
      return{
        arr:[
          {
            tlt:"华语新碟榜",
            inArr:[
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
            ]
          },
          {
            tlt:"欧美新碟榜",
            inArr:[
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/music_03.jpg'),
                name:'陈奕迅',
                comment:"暂无评论"
              },
            ]
          }
        ]
      }
    }
  }
</script>
