<template>
  <div class="homeitem">
      <div class="home_left">
          <h4 v-text="title">我在论文“造假”工厂打工:代写、包发,年产值10亿</h4>
          <p v-text="inner">只需要三四个小时，就能攒出一篇完全可以骗过查重系统的课程论文。</p>
          <span v-text="author">作者：土豆公社</span>
      </div>
      <div class="home_right"><img :src="url"></div>
  </div>
</template>
<script>
  export default{
      props:['title','inner','author','url']
  }
</script>
<style>
  .homeitem{padding: 20px;text-align: left}
  .home_left{width: 256px;display: inline-block}
  .home_left p{font-size: 12px;color: #bdbdbd;padding-top: 14px;padding-bottom: 18px}
  .home_left h4{font-size: 16px;font-family: '宋体';;line-height: 21px}
  .home_left span{font-size: 12px;color: #dedede}
  .home_right{width: 90px;height: 90px;float: right}
  .home_right img{width: 90px;}
</style>
