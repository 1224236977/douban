<template>
  <div class="audioitem">
      <div class="audio_top">
          <h4 v-text="tlt">影院热映</h4>
          <div class="more">更多<img src="../assets/images/audio_03.jpg"></div>
      </div>
      <div class="audioPiclist clearfix"><slot></slot></div>
  </div>
</template>
<script>
  export default{
      props:['tlt']
  }
</script>
<style>
  .audioitem{padding-left: 15px;background-color: #fff;margin-bottom: 20px;padding-bottom: 20px;}
  .audio_top{height: 65px;line-height: 65px;}
  .audio_top h4{float: left}
  .more{float: right;color: #2ba737;padding-right: 18px;}
  .more img{width: 6px;height: 10px;margin-left: 5px}
  .audioPiclist{overflow: hidden;width: 2000px;}
  .clearfix::after{content: "200B";height:0;font-size: 0;display: block;clear: both;}
</style>
