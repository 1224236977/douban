<template>
  <div class="city_main">
    <div class="location">
      <div class="l_city">当前城市：<span>{{ city }}</span></div>
      <div class="l_city">类型 时间 地点</div>
    </div>
    <AudioItem v-for="(item,index) in arr" :key="item.id" :tlt="item.tlt">
      <AudioPic v-for="(item2,index) in item.inArr" :key="item.id" :adurl="item2.adurl" :name="item2.name" :comment="item2.comment"></AudioPic>
    </AudioItem>
  </div>
</template>
<script>
  import AudioItem from './AudioItem'
  import AudioPic from './AudioPic'
  export default{
    components:{
      AudioItem,
      AudioPic
    },
    data:function () {
      return{
        arr:[
          {
            tlt:"热门活动",
            inArr:[
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
            ]
          },
          {
            tlt:"官方售票",
            inArr:[
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
              {
                adurl:require('../assets/images/city1_03.jpg'),
                name:'话剧《白鹿原》',
                comment:"暂无评论"
              },
            ]
          },
        ],
        city:"武汉"
      }
    }
  }
</script>
<style>
  .location{height: 46px;background: #fff;margin-top: 10px;margin-bottom: 15px;line-height: 46px;color:#bdbdbd}
  .location span{color: #62c16f}
  .l_city{width:173px;margin: 0px 17px;float: left;background: url("../assets/images/city2_03.jpg") no-repeat center right;}
</style>
