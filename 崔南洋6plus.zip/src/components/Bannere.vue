<template>
  <div class="swiper-container" :class="swiperid">
      <div class="swiper-wrapper">
          <!--<div class="swiper-slide">-->
            <slot name="swiper-con"></slot>
          <!--</div>-->
          <!--<slot></slot>-->
      </div>
      <div :class='{"swiper-pagination":pagination}' :style='{"text-align":paginationDirection}'></div>
      <div :class='{"swiper-button-prev":button}'></div>
      <div :class='{"swiper-button-next":button}'></div>
  </div>
</template>
<script>
  import '../assets/libs/swiper/js/swiper.js'
  export default{
      props:{
        swiperid:{
          type:String,
          default:''
        },
        pagination:{
            type:Boolean,
            default:true
        },
        paginationDirection:{
            type:String,
            default:"center"
        },
        loop:{
            type:Boolean,
            default:true
        },
        autoplay:{
            type:Number,
            default:1500,
        },
        effect:{
            type:String,
            default:'slide'
        },
        direction:{
            type:String,
            default:'horizontal'
        },
        paginationType:{
            type:String,
            default:'bullets'
        },
        button:{
            type:Boolean,
            default:false
        }
      },
      mounted:function () {
        var That=this;
        new Swiper('.'+That.swiperid,{
          pagination:'.swiper-pagination',
          prevButton:'.swiper-button-prev',
          nextButton:'.swiper-button-next',
          paginationType:That.paginationType,
          direction:That.direction,
          effect:That.direction,
          autoplay:That.autoplay,
          loop:That.loop,
          autoplayDisableOnInteraction:false,
          paginationClickable:true,
          touchMoveStopPropagation : false,
          touchRatio:0.4
        })
      },
  }
</script>
<style>
  @import "../assets/libs/swiper/css/swiper.css";
  .swiper-container img{width: 100%}
  .swiper-pagination-bullet-active{background-color: white}
  .banner .swiper-button-prev{width: 28px;height: 20px;}
  .banner .swiper-button-next{width: 28px;height: 20px;}
</style>
