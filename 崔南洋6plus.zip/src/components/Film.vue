<template>
  <div class="film_main">
      <AudioItem v-for="(item,index) in arr" :key="item.id" :tlt="item.tlt">
        <AudioPic v-for="(item2,index) in item.inArr" :key="item.id" :adurl="item2.adurl" :name="item2.name" :comment="item2.comment"></AudioPic>
      </AudioItem>
  </div>
</template>
<script>
  import AudioItem from './AudioItem'
  import AudioPic from './AudioPic'
  export default{
    components:{
        AudioItem,
        AudioPic
    },
    data:function () {
      return{
          arr:[
            {
                tlt:"影院热映",
                inArr:[
                  {
                    adurl:require('../assets/images/film_03.jpg'),
                    name:'小情人',
                    comment:"暂无评论"
                  },
                  {
                    adurl:require('../assets/images/film_03.jpg'),
                    name:'小情人',
                    comment:"暂无评论"
                  },
                  {
                    adurl:require('../assets/images/film_03.jpg'),
                    name:'小情人',
                    comment:"暂无评论"
                  },
                  {
                    adurl:require('../assets/images/film_03.jpg'),
                    name:'小情人',
                    comment:"暂无评论"
                  },
                ]
            },
            {
              tlt:"院线即将上映",
              inArr:[
                {
                  adurl:require('../assets/images/film_03.jpg'),
                  name:'小情人',
                  comment:"暂无评论"
                },
                {
                  adurl:require('../assets/images/film_03.jpg'),
                  name:'小情人',
                  comment:"暂无评论"
                },
                {
                  adurl:require('../assets/images/film_03.jpg'),
                  name:'小情人',
                  comment:"暂无评论"
                },
                {
                  adurl:require('../assets/images/film_03.jpg'),
                  name:'小情人',
                  comment:"暂无评论"
                },
              ]
            }
          ]
      }
    }
  }
</script>
<style>
  .film_main,.book_main,.tv_main,.city_main,.music_main{background-color: #f7f7f7;padding-top: 10px;text-align: left}
</style>
