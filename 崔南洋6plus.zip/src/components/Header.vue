<template>
    <div class="header" :style="{backgroundColor:col}">
        <slot></slot>
        <span class="leftImg"><slot name="leftImg"></slot></span>
        <span class="rightImg"><slot name="rightImg"></slot></span>
    </div>
</template>
<script>
  export default {
      props:{
          col:{
              default:'#f9f9f9'
          },
      }
  }
</script>
<style>
    .header{height: 44px;padding-top: 20px;line-height: 44px;font-size: 16px;
      position: relative}
    .leftImg,.rightImg{width: 44px;position: absolute;margin-right: 10px;display: inline-block;height: 44px;right: 0
      ;top: 17px;}
    .leftImg{right: 54px}
    .leftImg img,.rightImg img{width: 24px;vertical-align: middle}
</style>
