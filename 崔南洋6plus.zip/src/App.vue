<template>
  <div id="app">
      <router-view></router-view>
      <Tabber></Tabber>
  </div>
</template>

<script>
  import Tabber from './components/Tabbar'
  export default {
      name: 'app',
      components:{
          Tabber
      },
      created:function () {
          this.$router.push('/Home')
      }
  }
</script>

<style>
*{margin: 0;padding: 0}
li{list-style: none}
a{text-decoration: none}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif ,微软雅黑;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}
</style>
